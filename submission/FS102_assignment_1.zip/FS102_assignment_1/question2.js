var userInputNum1 = parseFloat(prompt("Please enter the 1st number:"));
var userInputNum2 = parseFloat(prompt("Please enter the 2nd number:"));

var sum = userInputNum1+userInputNum2;

console.log("The sum of two number is : "+sum);