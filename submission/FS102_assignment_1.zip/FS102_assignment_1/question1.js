var userInput = prompt("Please enter a number:");


console.log("The number is: " + userInput);