
var string = "this is a sentence";

for(var i = 0; i<= string.length; i++)
{
    console.log(i);
}