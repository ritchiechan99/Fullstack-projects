var userInput = parseFloat(prompt("Please enter a number: "));

if(userInput % 2 === 0)
{
    console.log("The number is even.");
}
else
{
    console.log("The number is odd.");
}